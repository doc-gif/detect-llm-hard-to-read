def run(values, target):
    ordered = sorted(values)
    size = len(ordered)
    left = 0
    right = size
    while left < right:
        left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] < target else (left, (left + right) // 2)
    first = left
    right = size
    while left < right:
        left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] <= target else (left, (left + right) // 2)
    last = left
    count = last - first
    prefix = [0]
    for value in ordered:
        prefix.append(prefix[-1] + value)
    below = prefix[first]
    equal = prefix[last] - prefix[first]
    above = prefix[-1] - prefix[last]
    summary = [first, count, below, equal, above]
    if count == 0:
        return summary + [-1]
    return summary + [first]
