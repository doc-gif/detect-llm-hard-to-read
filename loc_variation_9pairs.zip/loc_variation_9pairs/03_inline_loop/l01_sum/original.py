def run(values):
    total = 0
    for value in values:
        total += value
    return total
