def run(values):
    total = 0
    squares = 0
    counts = {}
    for value in values:
        total += value
    for value in values:
        squares += value * value
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    frequencies = sorted(counts.items())
    return [total, squares, frequencies]
