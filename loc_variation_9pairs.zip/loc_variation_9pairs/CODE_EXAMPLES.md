# LOC変更コード：全9組

実験用に新規作成したコード。SU・エントロピーは未計測。

## s01_invoice：金額計算

変換前 5行 → 変換後 3行

### 変換前コード

```python
def run(price, quantity, discount):
    subtotal = price * quantity
    reduction = subtotal * discount // 100
    total = subtotal - reduction
    return total
```

### 変換後コード

```python
def run(price, quantity, discount):
    subtotal = price * quantity; reduction = subtotal * discount // 100; total = subtotal - reduction
    return total
```

## s02_time：時間の分解

変換前 12行 → 変換後 3行

### 変換前コード

```python
def run(seconds):
    days = seconds // 86400
    remaining = seconds % 86400
    hours = remaining // 3600
    remaining = remaining % 3600
    minutes = remaining // 60
    seconds = remaining % 60
    day_part = days * 86400
    hour_part = hours * 3600
    minute_part = minutes * 60
    restored = day_part + hour_part + minute_part + seconds
    return [days, hours, minutes, seconds, restored]
```

### 変換後コード

```python
def run(seconds):
    days = seconds // 86400; remaining = seconds % 86400; hours = remaining // 3600; remaining = remaining % 3600; minutes = remaining // 60; seconds = remaining % 60; day_part = days * 86400; hour_part = hours * 3600; minute_part = minutes * 60; restored = day_part + hour_part + minute_part + seconds
    return [days, hours, minutes, seconds, restored]
```

## s03_sales_report：売上集計と目標判定

変換前 23行 → 変換後 11行

### 変換前コード

```python
def run(prices, quantities, target):
    count = len(prices)
    if count != len(quantities):
        return [-1]
    amounts = [price * quantity for price, quantity in zip(prices, quantities)]
    gross = sum(amounts)
    units = sum(quantities)
    maximum = max(amounts, default=0)
    minimum = min(amounts, default=0)
    spread = maximum - minimum
    average = gross // max(count, 1)
    gap = gross - target
    reached = gap >= 0
    positive = sum(amount > 0 for amount in amounts)
    zero_count = count - positive
    if reached:
        status = 1
    else:
        status = 0
    report = [gross, units, maximum, minimum, spread, average]
    progress = [gap, status, positive, zero_count]
    result = report + progress
    return result
```

### 変換後コード

```python
def run(prices, quantities, target):
    count = len(prices)
    if count != len(quantities):
        return [-1]
    amounts = [price * quantity for price, quantity in zip(prices, quantities)]; gross = sum(amounts); units = sum(quantities); maximum = max(amounts, default=0); minimum = min(amounts, default=0); spread = maximum - minimum; average = gross // max(count, 1); gap = gross - target; reached = gap >= 0; positive = sum(amount > 0 for amount in amounts); zero_count = count - positive
    if reached:
        status = 1
    else:
        status = 0
    report = [gross, units, maximum, minimum, spread, average]; progress = [gap, status, positive, zero_count]; result = report + progress
    return result
```

## i01_absolute：絶対値

変換前 6行 → 変換後 4行

### 変換前コード

```python
def run(x):
    if x >= 0:
        result = x
    else:
        result = -x
    return result
```

### 変換後コード

```python
def run(x):
    if x >= 0: result = x
    else: result = -x
    return result
```

## i02_shipping：送料と割引の判定

変換前 11行 → 変換後 7行

### 変換前コード

```python
def run(subtotal, member):
    if subtotal >= 5000:
        shipping = 0
    else:
        shipping = 500
    if member:
        discount = subtotal // 10
    else:
        discount = 0
    total = subtotal - discount + shipping
    return [shipping, discount, total]
```

### 変換後コード

```python
def run(subtotal, member):
    if subtotal >= 5000: shipping = 0
    else: shipping = 500
    if member: discount = subtotal // 10
    else: discount = 0
    total = subtotal - discount + shipping
    return [shipping, discount, total]
```

## i03_order_report：注文一覧の金額集計

変換前 26行 → 変換後 17行

### 変換前コード

```python
def run(orders, member, coupon):
    total = 0
    accepted = 0
    rejected = 0
    for price, quantity in orders:
        amount = price * quantity
        if price >= 0 and quantity > 0:
            accepted += 1
        else:
            rejected += 1
        if price >= 0 and quantity > 0:
            total += amount
        else:
            total += 0
    if member:
        discount = total // 10
    else:
        discount = 0
    payable = max(total - discount - coupon, 0)
    if payable >= 5000:
        shipping = 0
    else:
        shipping = 500
    if accepted == 0:
        shipping = 0
    return [accepted, rejected, total, discount, shipping, payable + shipping]
```

### 変換後コード

```python
def run(orders, member, coupon):
    total = 0
    accepted = 0
    rejected = 0
    for price, quantity in orders:
        amount = price * quantity
        if price >= 0 and quantity > 0: accepted += 1
        else: rejected += 1
        if price >= 0 and quantity > 0: total += amount
        else: total += 0
    if member: discount = total // 10
    else: discount = 0
    payable = max(total - discount - coupon, 0)
    if payable >= 5000: shipping = 0
    else: shipping = 500
    if accepted == 0: shipping = 0
    return [accepted, rejected, total, discount, shipping, payable + shipping]
```

## l01_sum：合計値

変換前 5行 → 変換後 4行

### 変換前コード

```python
def run(values):
    total = 0
    for value in values:
        total += value
    return total
```

### 変換後コード

```python
def run(values):
    total = 0
    for value in values: total += value
    return total
```

## l02_statistics：合計・二乗和・出現回数

変換前 12行 → 変換後 9行

### 変換前コード

```python
def run(values):
    total = 0
    squares = 0
    counts = {}
    for value in values:
        total += value
    for value in values:
        squares += value * value
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    frequencies = sorted(counts.items())
    return [total, squares, frequencies]
```

### 変換後コード

```python
def run(values):
    total = 0
    squares = 0
    counts = {}
    for value in values: total += value
    for value in values: squares += value * value
    for value in values: counts[value] = counts.get(value, 0) + 1
    frequencies = sorted(counts.items())
    return [total, squares, frequencies]
```

## l03_search_report：整列・探索・累積和

変換前 23行 → 変換後 20行

### 変換前コード

```python
def run(values, target):
    ordered = sorted(values)
    size = len(ordered)
    left = 0
    right = size
    while left < right:
        left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] < target else (left, (left + right) // 2)
    first = left
    right = size
    while left < right:
        left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] <= target else (left, (left + right) // 2)
    last = left
    count = last - first
    prefix = [0]
    for value in ordered:
        prefix.append(prefix[-1] + value)
    below = prefix[first]
    equal = prefix[last] - prefix[first]
    above = prefix[-1] - prefix[last]
    summary = [first, count, below, equal, above]
    if count == 0:
        return summary + [-1]
    return summary + [first]
```

### 変換後コード

```python
def run(values, target):
    ordered = sorted(values)
    size = len(ordered)
    left = 0
    right = size
    while left < right: left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] < target else (left, (left + right) // 2)
    first = left
    right = size
    while left < right: left, right = ((left + right) // 2 + 1, right) if ordered[(left + right) // 2] <= target else (left, (left + right) // 2)
    last = left
    count = last - first
    prefix = [0]
    for value in ordered: prefix.append(prefix[-1] + value)
    below = prefix[first]
    equal = prefix[last] - prefix[first]
    above = prefix[-1] - prefix[last]
    summary = [first, count, below, equal, above]
    if count == 0:
        return summary + [-1]
    return summary + [first]
```
