def run(orders, member, coupon):
    total = 0
    accepted = 0
    rejected = 0
    for price, quantity in orders:
        amount = price * quantity
        if price >= 0 and quantity > 0: accepted += 1
        else: rejected += 1
        if price >= 0 and quantity > 0: total += amount
        else: total += 0
    if member: discount = total // 10
    else: discount = 0
    payable = max(total - discount - coupon, 0)
    if payable >= 5000: shipping = 0
    else: shipping = 500
    if accepted == 0: shipping = 0
    return [accepted, rejected, total, discount, shipping, payable + shipping]
