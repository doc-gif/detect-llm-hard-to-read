def run(subtotal, member):
    if subtotal >= 5000: shipping = 0
    else: shipping = 500
    if member: discount = subtotal // 10
    else: discount = 0
    total = subtotal - discount + shipping
    return [shipping, discount, total]
