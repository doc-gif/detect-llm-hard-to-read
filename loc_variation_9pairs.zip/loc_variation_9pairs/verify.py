"""同梱の既知コード9組を検証する。外部ライブラリ不要。"""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    rows = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    report = []
    for row in rows:
        functions = []
        sources = []
        for kind in ('original', 'transformed'):
            path = ROOT / row[kind]
            source = path.read_text(encoding='utf-8')
            assert hashlib.sha256(source.encode()).hexdigest() == row[kind + '_sha256'], path
            assert len(source.splitlines()) == row[kind + '_LOC'], path
            namespace = {}
            exec(compile(source, str(path), 'exec'), namespace)
            functions.append(namespace['run'])
            sources.append(source)
        assert ast.dump(ast.parse(sources[0]), include_attributes=False) == ast.dump(ast.parse(sources[1]), include_attributes=False), row['case_id']
        tests = json.loads((ROOT / row['original']).with_name('tests.json').read_text(encoding='utf-8'))
        for index, test in enumerate(tests):
            # JSON roundtrip permits list/tuple equivalence in the result representation.
            results = [json.loads(json.dumps(fn(*test['args']), ensure_ascii=False)) for fn in functions]
            assert results[0] == results[1] == test['expected'], (row['case_id'], index, results, test['expected'])
        report.append({'case_id': row['case_id'], 'AST_equal': True, 'LOC_checked': True, 'tests_passed': len(tests)})
        print(f"{row['case_id']}: {row['original_LOC']} -> {row['transformed_LOC']} LOC; {len(tests)} tests PASS")
    (ROOT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f"Total: {len(rows)} pairs, {sum(r['tests_passed'] for r in report)} inputs PASS")

if __name__ == '__main__':
    main()
