def run(prices, quantities, target):
    count = len(prices)
    if count != len(quantities):
        return [-1]
    amounts = [price * quantity for price, quantity in zip(prices, quantities)]; gross = sum(amounts); units = sum(quantities); maximum = max(amounts, default=0); minimum = min(amounts, default=0); spread = maximum - minimum; average = gross // max(count, 1); gap = gross - target; reached = gap >= 0; positive = sum(amount > 0 for amount in amounts); zero_count = count - positive
    if reached:
        status = 1
    else:
        status = 0
    report = [gross, units, maximum, minimum, spread, average]; progress = [gap, status, positive, zero_count]; result = report + progress
    return result
