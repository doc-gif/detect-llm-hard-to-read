def run(price, quantity, discount):
    subtotal = price * quantity; reduction = subtotal * discount // 100; total = subtotal - reduction
    return total
