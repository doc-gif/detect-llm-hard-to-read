def run(seconds):
    days = seconds // 86400
    remaining = seconds % 86400
    hours = remaining // 3600
    remaining = remaining % 3600
    minutes = remaining // 60
    seconds = remaining % 60
    day_part = days * 86400
    hour_part = hours * 3600
    minute_part = minutes * 60
    restored = day_part + hour_part + minute_part + seconds
    return [days, hours, minutes, seconds, restored]
